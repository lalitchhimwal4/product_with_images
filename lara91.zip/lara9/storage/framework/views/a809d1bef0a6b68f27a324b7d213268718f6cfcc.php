
<h1>All Post</h1>
<table> 
    <tr>
        <td><b>S.No.</b></td>
        <td><b>Title</b></td>
        <td><b>Description</b></td>
    </tr>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($i+1); ?></td>
        <td><?php echo e($post->title); ?></td>
        <td><?php echo e($post->description); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\lalit\lara9\resources\views/post/list.blade.php ENDPATH**/ ?>